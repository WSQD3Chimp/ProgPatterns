/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Administrator
 */
public class Lab6q4 {
    public static void main(String[] args) throws Exception{
    Class.forName("org.sqlite.JDBC");
            Connection con = DriverManager.getConnection("jdbc:sqlite:C:\\Sql Light\\Databasses\\chinook.db");
            Statement stmt = con.createStatement();
            
            System.out.println("Getting employees table data");
            String queryTable = "select * from employees";
            ResultSet rs = stmt.executeQuery(queryTable);
            
            while (rs.next()){
                System.out.println("Name: " + rs.getString("FirstName") + rs.getString("LastName"));   
                System.out.println("Adress: " + rs.getString("Address") );
            }
    }
}