/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Administrator
 */
public class Lab6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Class.forName("org.sqlite.JDBC");
            Connection con =DriverManager.getConnection("jdbc:sqlite:C:\\Sql Light\\Databasses\\example.db");
            Statement stmt = con.createStatement();
            
            String createTable = "CREATE TABLE COMPANY " +
                "(ID INT PRIMARY KEY     NOT NULL," +
                " NAME           TEXT    NOT NULL, " + 
                " AGE            INT     NOT NULL, " + 
                " ADDRESS        CHAR(50), " + 
                " SALARY         REAL)";  
            
            stmt.executeUpdate("DROP table if exists COMPANY");
            stmt.executeUpdate(createTable);
            
            String insertInTable = "INSERT INTO COMPANY(ID,NAME,AGE,ADDRESS,SALARY) " +
               "VALUES (1, 'Djo', 32, 'California', 20000.00 );"; 
            stmt.executeUpdate(insertInTable);
            insertInTable = "INSERT INTO COMPANY(ID,NAME,AGE,ADDRESS,SALARY) " +
               "VALUES (2, 'oui', 55, 'California girls', 0000.00 );";
            stmt.executeUpdate(insertInTable);
            
            
            System.out.println("Getting company table data");
            String queryTable = "select * from COMPANY ";
            ResultSet rs = stmt.executeQuery(queryTable);
            while (rs.next()) {	
                int id = rs.getInt("ID");
                String name = rs.getString("NAME");
                int age  = rs.getInt("age");
                String  address = rs.getString("address");
                float salary = rs.getFloat("salary");
                System.out.println( "ID = " + id );
                System.out.println( "NAME = " + name );
                System.out.println( "AGE = " + age );
                System.out.println( "ADDRESS = " + address );
                System.out.println( "SALARY = " + salary );
            }
            stmt.close();
            con.close();
            
        } catch (Exception e) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
            System.exit(0);   
        }

    }
    
}
