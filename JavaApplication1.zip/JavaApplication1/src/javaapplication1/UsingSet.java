/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Administrator
 */
class Book implements Comparable<Book>{
    private String title;
    private int paper;
    private String author;

    public Book(String title, int paper, String author) {
        this.title = title;
        this.paper = paper;
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPaper() {
        return paper;
    }

    public void setPaper(int paper) {
        this.paper = paper;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.title);
        hash = 59 * hash + Objects.hashCode(this.author);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Book other = (Book) obj;
        if (!Objects.equals(this.title, other.title)) {
            return false;
        }
        if (!Objects.equals(this.author, other.author)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Book{" + "title=" + title + ", paper=" + paper + ", author=" + author + '}';
    }

    @Override
    public int compareTo(Book o) {
        return this.paper - o.paper;
    }

 
    
    
}

public class UsingSet {
    public static void main(String[] rr){
        Book[] arr = {new Book("YEHA MAN", 12, "Black Man"), new Book("YEHA MAN", 12, "Black Man"), new Book("NAH MAN", 500, "Black Man 2"), new Book("YEAH MAN 2 RETURN OF THE YEAH", 24, "Black Man")};
        Set<Book> booksets = new LinkedHashSet(Arrays.asList(arr));
        
        //Set<Book> sortedSet = new TreeSet(booksets);
        Set<Book> sortedSet = new TreeSet<>((s1,s2) -> s1.getTitle().compareTo(s2.getTitle()));
        sortedSet.add(new Book("YEHA MAN", 12, "Black Man"));
        sortedSet.add(new Book("YEHA MAN", 12, "Black Man"));
        sortedSet.add(new Book("NAH MAN", 500, "Black Man 2"));
        sortedSet.add( new Book("YEAH MAN 2 RETURN OF THE YEAH", 24, "Black Man"));
        
        for(Book book: sortedSet)
            System.out.println(book);
        
//        for(Book book: booksets)
//            System.out.println(book);

        
//        Set<Book> bookSet = new HashSet();
//        
//        bookSet.add(new Book("YEHA MAN", 12, "Black Man"));
//        bookSet.add(new Book("YEHA MAN", 12, "Black Man"));
//        bookSet.add(new Book("NAH MAN", 500, "Black Man 2"));
//        bookSet.add(new Book("YEAH MAN 2 RETURN OF THE YEAH", 24, "Black Man"));
//        
//        for(Book book: bookSet) 
//            System.out.println(book);
    }
}
