/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

/**
 *
 * @author Administrator
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack <Integer> oneStack = new Stack<>();

        oneStack.push(new Integer(5)); // no need for Integer keyword
        oneStack.push(8);
        oneStack.push(100);

        while (!oneStack.isEmpty()) 
            System.out.println(oneStack.pop()); // dont peek loops that shit goes on forever


       
                Queue<String> myQueue = new   LinkedList<>(); 
 		myQueue.offer("Oklahoma"); 
		myQueue.offer("Indiana"); 
		myQueue.offer("Georgia"); 
		myQueue.offer("Texas"); 
		while (myQueue .size() > 0) {
                     System.out.println(myQueue.remove() + " ");  }  
    
    
    
    // priority queue
    PriorityQueue<String> queue1 = new PriorityQueue(Collections.reverseOrder());
     queue1.offer("Montreal");
     queue1.offer("Quebec");
     queue1.offer("yes");
     queue1.offer("notMontreal");
     
     while (!queue1.isEmpty()) {
         System.out.println(queue1.poll());
     }
     
     PriorityQueue<String> queue2 = new PriorityQueue<>((s1,s2) -> s1.length() - s2.length()); // 10 is the copacity for some reason
     queue2.offer("Montreal");
     queue2.offer("Quebec");
     queue2.offer("Quebec");
     queue2.offer("notMontreal");
     
     while (!queue2.isEmpty()) {
         System.out.println(queue2.poll());
     }
     
     
     
     
     // Hash sset's
     
     Set<String> set1 = new HashSet();
     set1.add("Mont");
     set1.add("Ottawa");
     set1.add("Toronto");
     set1.add("Quebec");
     set1.add("quebec");
     set1.add("Flor");
     set1.add("Ottawa");
     
     for(String city:set1)
            System.out.println(city.toUpperCase());
    }
    
}
