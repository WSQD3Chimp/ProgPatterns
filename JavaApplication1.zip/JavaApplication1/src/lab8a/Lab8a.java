/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8a;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Administrator
 */
class CountPrimes implements Runnable {

    private int min;
    private int max;
    public static int total;

    public CountPrimes(int min, int max) {
        this.min = min;
        this.max = max;
    }

    public void run() {
        synchronized(this){
        int count = 0;
        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                count++;
            }

        }
        System.out.println(Thread.currentThread().getName()+"-->The number of primes is :" + count);
        total +=count;
        }
    }

    private boolean isPrime(int x) {
        int top = (int) Math.sqrt(x);
        for (int i = 2; i <= top; i++) {
            if (x % i == 0) {
                return false;
            }
        }
        return true;
    }

}

class Lab8b {

    public static void main(String[] args) throws Exception {
        long startTime = System.currentTimeMillis();
        Thread[] allThreads = new Thread[4];
//        for(int i=0; i<=3;i++)allThreads[i] = new Thread(new CountPrimes(2000000*(i+1), 2000000*(i+1)+1000000));
        allThreads[0] = new Thread(new CountPrimes(2000000, 3000000));
        allThreads[1] = new Thread(new CountPrimes(3000001, 4000000));
        allThreads[2] = new Thread(new CountPrimes(4000001, 5000000));
        allThreads[3] = new Thread(new CountPrimes(5000001, 6000000));

        for(int i=0; i<=3;i++) allThreads[i].start();

         for(int i=0; i<=3;i++) {
         
         while(allThreads[i].isAlive()) allThreads[i].join();
         }
      
       long elapsedTime = System.currentTimeMillis() - startTime;
        System.out.println("Computation is done! in " + elapsedTime + "ms" + "Total PrimeNumbers " + CountPrimes.total);
    }
}



