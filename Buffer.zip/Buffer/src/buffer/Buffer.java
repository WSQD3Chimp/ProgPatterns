/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buffer;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Administrator
 */
public class Buffer {
private static ArrayBlockingQueue<Integer> buffer = new ArrayBlockingQueue<>(2);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Create a thread pool with two threads
        ExecutorService executor = Executors.newFixedThreadPool(2);
        executor.execute(new ProducerTask());
        executor.execute(new ConsumerTask());
        executor.shutdown();

    }
    
    public static class ConsumerTask implements Runnable {
        @Override
        public void run() {
            try {
                while (true) {
                System.out.println("\t\t\tConsumer reads " + buffer.take());
                Thread.sleep((int) (Math.random() * 10000)); 
                }
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            } 
        }
    }

    public static class ProducerTask implements Runnable {
        @Override
        public void run() {
            try {
                int i = 1;
                while (true) {
                    System.out.println("Producer writes " + i);
                    buffer.put(i++);
                    Thread.sleep((int) (Math.random() * 10000));
                }
            } catch (InterruptedException ex) {
                ex.printStackTrace();  
            }
        } 
    }     
}
