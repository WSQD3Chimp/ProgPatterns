/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreadingpennys;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author Administrator
 */
public class Account {
    private int balance = 0;
    private static Lock lock = new ReentrantLock(true);

    public int getBalance() {
      return balance;    }
    
    //or public synchronized void deposit(int amount) {
    public void deposit(int amount) {
        //synchronized(this){
            lock.lock();
            int newBalance = balance + amount;
            balance = newBalance;

            // This delay is deliberately added to magnify the
            // data-corruption problem and make it easy to see.
            try {    
                Thread.sleep(5);     
            }
            catch (InterruptedException ex) {  

            }
            finally {
                lock.unlock();
            }
        //}
     
    }
}
