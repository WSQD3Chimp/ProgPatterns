/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreadingpennys;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Administrator
 */
public class MultiThreadingPennys {
    
private static Account account = new Account();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool();

        // Create and launch 100 threads
        for (int i = 0; i < 100; i++) {
             executor.execute(new AddAPennyTask(account));
        }

        executor.shutdown();

        // Wait until all tasks are finished
        while (!executor.isTerminated()) {  

        }

        System.out.println("What is balance? " +  account.getBalance());

    }
    
}
