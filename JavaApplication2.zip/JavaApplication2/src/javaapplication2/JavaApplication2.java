/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Administrator
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        Thread[] th = new Thread[1000];
        
        for(int i = 0; i <1000; i++) {
            th[i] = new Thread(new AddingOne());
            th[i].start();
        }
        
        for(int i=0; i<1000;i++) {
         
            while(th[i].isAlive()){
                th[i].join();
            }
        }
        System.out.println("All threads done.... Sum is " + AddingOne.sum);
        
        
        
        
        
        ExecutorService exe = Executors.newCachedThreadPool();
        
        for(int i = 0; i <1000; i++) {
            exe.equals(new AddingOne());
        }
        exe.shutdown();
        while(!exe.isTerminated()) {
            
        }
        System.out.println("All threads done.... Sum is " + AddingOne.sum);
        
    }
}
