/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Administrator
 */
public class AddingOne implements Runnable{
    static Integer sum  = 0;

    @Override
    public void run() {
        addOne();
    }
    
    public synchronized static void addOne(){
        sum +=1;
    }
}
