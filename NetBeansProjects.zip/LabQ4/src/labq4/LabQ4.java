/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labq4;

/**
 *
 * @author Administrator
 */
public class LabQ4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Car car1 = retrieveCar();
        ViewCar v1 = new ViewCar();
        CarControler cr1 = new CarControler(car1, v1);
        //System.out.println(car1); becomes
        cr1.updateView();
        cr1.Faster();
        cr1.updateView();
        
//        System.out.println("The cars speed is " + car1.getSpeed());
//        int y = 1;
//        int i = 1;
////        while(i < 5) {
////            car1.accelerate();
////            System.out.println("The cars speed is " + car1.getSpeed());
////            i++;
////        }
//        
//        car1.setSpeed(30);
//        while(i < 7) {
//            car1.breaks();
//            System.out.println(car1);
//            i++;
//        }
        

    }
    public static Car retrieveCar() {
        return new Car(3055, "tesla");
    }   
}
