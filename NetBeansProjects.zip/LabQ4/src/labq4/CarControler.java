/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labq4;

/**
 *
 * @author Administrator
 */
public class CarControler {
    private Car c1;
    private ViewCar view;

    public CarControler(Car c1, ViewCar view) {
        this.c1 = c1;
        this.view = view;
    }
    
    public int YearM() {
        return c1.getYearModel();
    }
    
    public String CarMake() {
        return c1.getMake();
    }
    
    public int HowFast() {
        return c1.getSpeed();
    }
    
    public void Faster() {
        c1.accelerate();
    }
    
    public void SlowDown() {
        c1.breaks();
    }
    
    public void updateView() {
        view.PrintCarInfo(c1);
    }
}
