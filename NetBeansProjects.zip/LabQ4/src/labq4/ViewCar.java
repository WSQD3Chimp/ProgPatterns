/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labq4;

/**
 *
 * @author Administrator
 */
public class ViewCar {
    public void PrintCarInfo(Car c){
        System.out.println(c);
    }
}
