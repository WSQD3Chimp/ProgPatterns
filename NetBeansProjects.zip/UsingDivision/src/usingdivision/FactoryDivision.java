/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usingdivision;

/**
 *
 * @author Administrator
 */
public class FactoryDivision {
    
    public static Division createDivision(int choice, String Country_State, String language, String name, int acountNum) throws Exception{
        switch (choice) {
            case 1: 
                return new InternationalDivision(Country_State, language, name, acountNum);
            case 2:
                return new DomesticDivision(Country_State, name, acountNum);
            default:
                throw new Exception("Invalid division choice");
        }
    }
}
