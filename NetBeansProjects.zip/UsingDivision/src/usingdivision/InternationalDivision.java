/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usingdivision;

/**
 *
 * @author Administrator
 */
public class InternationalDivision extends Division{
    private String country;
    private String language;

    public InternationalDivision(String country, String language, String divName, int acountNum) {
        super(divName, acountNum);
        this.country = country;
        this.language = language;
    }
    
    @Override
    public void display() {
        super.display();
        System.out.println("Country " + country + ", Language " + language);
    }
}
