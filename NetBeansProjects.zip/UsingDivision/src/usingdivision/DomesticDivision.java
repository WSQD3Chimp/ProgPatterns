/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usingdivision;

/**
 *
 * @author Administrator
 */
public class DomesticDivision extends Division{
    private String state;

    public DomesticDivision(String state, String divName, int acountNum) {
        super(divName, acountNum);
        this.state = state;
    }

    
    
    @Override
    public void display() {
        super.display();
        System.out.println("State " + state);
    }
}
