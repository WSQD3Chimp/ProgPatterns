/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usingdivision;

/**
 *
 * @author Administrator
 */
public class UsingDivision {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
//        InternationalDivision i1 = new InternationalDivision("Canada", "English", "division 1", 4562348);
//        DomesticDivision d1 = new DomesticDivision("Alabama", "Division 2", 6684844);
//        
//        i1.display();
//        d1.display();

          FactoryDivision f1 = new FactoryDivision();
          Division div1 = f1.createDivision(1, "Canada", "EN/FR", "Div1", 46466);
          
          FactoryDivision f2 = new FactoryDivision();
          Division div2 = f2.createDivision(2, "Alabama", "", "Div2", 1616156161);
          
          div1.display();
          div2.display();
    }
}
