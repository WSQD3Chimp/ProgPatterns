/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usingdivision;

/**
 *
 * @author Administrator
 */
public class Division {
    protected String divName;
    protected int acountNum;

    public Division(String divName, int acountNum) {
        this.divName = divName;
        this.acountNum = acountNum;
    }
    
    public void display() {
        System.out.println("Divison name " + divName + "Acount Number " + acountNum);
    }
}
