/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3q4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.TreeMap;

/**
 *
 * @author sebas
 */
public class Lab3Q4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> s1Course = new ArrayList<>();
        s1Course.add("CS200");
        s1Course.add("CS100");
        
        ArrayList<String> s2Course = new ArrayList<>();
        s2Course.add("MATH210");
        s2Course.add("CS105");
        
        HashMap<Integer, ArrayList<String>> students = new HashMap<>();
        students.put(1, s1Course);
        students.put(2, s2Course);
        
        System.out.println("Struden 1's courses " + students.get(1));
        System.out.println("Struden 2's courses " + students.get(2));
        
        Collections.sort(s1Course);
        Collections.sort(s2Course);
        
        TreeMap<Integer, ArrayList<String>> t1 = new TreeMap<>(students);
        System.out.println(t1);
    }
}
